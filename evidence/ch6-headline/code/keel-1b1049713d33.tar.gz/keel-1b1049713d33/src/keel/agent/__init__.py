"""Agent harness: sandbox, loop, tasks (plan v8, modules 1-2)."""
