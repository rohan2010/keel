"""keel-core: command-line entry point for the Python core.

  keel-core eval --suite agent --arm base --split dev        any suite as a named arm (tries, repeats; Ch4)
  keel-core eval --list                                      suites, splits, item counts, sealed tiers
  keel-core compare <runA> <runB>                            verdict: gain / loss / no effect / can't compare
  keel-core run --name smoke --tasks A3 F1 --per-task 1      agent tasks (same flags as scripts/run_agent.py)
  keel-core bfcl-mt --name smoke --split dev --limit 3       BFCL multi-turn (same flags as scripts/run_bfcl_mt.py)
  keel-core when2call --name w2c --split dev [--probe-gate]  When2Call (call / no-call decisions)
  keel-core acp                                              ACP agent on stdio (the `keel` TUI, Zed, ...)
  keel-core backups [<session>] [--restore N]                silent backups of changed / deleted files
  keel-core doctor [--backend mlx-server]                    what this Mac and a model server can do
"""

import argparse

from keel import acp_server, doctor
from keel.commands import run_agent, run_backups, run_baseline, run_bfcl_mt, run_compare, run_eval, run_noise, run_prereg, run_when2call

COMMANDS = {
    "eval": (run_eval, "run a suite as a named arm (tries, repeats) and write one record shape (Ch4)"),
    "compare": (run_compare, "verdict on two arms: real gain / loss / no detectable effect / can't compare (Ch4)"),
    "noise": (run_noise, "record or list noise bands (how far two identical runs disagree; Ch4)"),
    "prereg": (run_prereg, "freeze a pre-registration before the runs exist (Ch4)"),
    "run": (run_agent, "run the model through the agent tasks"),
    "bfcl-mt": (run_bfcl_mt, "BFCL v4 multi-turn eval, scored with the official checker"),
    "when2call": (run_when2call, "When2Call call / ask / can't-answer eval, gate off or on (P8)"),
    "acp": (acp_server, "serve the agent over ACP on stdio (for the keel TUI and other ACP clients)"),
    "baseline": (run_baseline, "run an off-the-shelf agent (goose, opencode) on keel's tasks, sandboxed (Ch6)"),
    "backups": (run_backups, "list or restore the silent backups kept before a file changes or is deleted"),
    "doctor": (doctor, "check this Mac and a model server; writes the server's capabilities record"),
}


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="keel-core", description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="command", required=True, metavar="COMMAND")
    for name, (mod, help_) in COMMANDS.items():
        p = sub.add_parser(name, help=help_, description=mod.__doc__.splitlines()[0],
                           allow_abbrev=name != "eval")   # eval passes unknown flags on: no prefix guessing
        mod.add_arguments(p)
        p.set_defaults(_run=mod.run)
    return ap


def main(argv=None) -> None:
    ap = build_parser()
    a, extra = ap.parse_known_args(argv)
    if extra and a.command != "eval":                  # only eval passes unknown flags on (to the suite's command)
        ap.error(f"unrecognized arguments: {' '.join(extra)}")
    if a.command == "eval":
        a._extra = extra
    run = a._run
    del a._run, a.command
    run(a)


if __name__ == "__main__":
    main()
