"""Chapter 4 P8: keel compare on four saved results, offline (no model). Prints a table for the write-up.

  uv run python scripts/ch4_reproduce.py

Needs the research snapshot (results/runs), the P8 When2Call runs (experiments/) and, for the agent result scored as
it was published, the research repo (~/Desktop/exp-weights, read only).
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))

from keel.evals import runs  # noqa: E402
from keel.evals.compare import compare_arms, load_arm  # noqa: E402
from test_compare import research_arm  # noqa: E402

RESEARCH, EXP = ROOT / "results" / "runs", ROOT / "experiments"


def d(base, tag):
    return str(next(p for p in runs.find_runs(base) if tag in p.name))


def main() -> int:
    rows = []
    no = d(RESEARCH, "m1_mf_noreminder_s0") + "," + d(RESEARCH, "m1_mf_noreminder_s1")
    f = d(RESEARCH, "m1_mf_F_s0") + "," + d(RESEARCH, "m1_mf_F_s1")
    rows.append(("Keep reminder (Milestone 1)", "27 vs 4 of 100, p = 1.7e-5",
                 compare_arms(load_arm(no), load_arm(f), pair="try", sided="greater")))
    rows.append(("File tools vs shell (Module 2)", "+13.9 [+7.2, +20.6]",
                 compare_arms(research_arm(("20261107-193938", "20261107-201823", "20261107-212144"), "20261110-1650"),
                              research_arm(("20261107-230318", "20261107-235713", "20261108-005431"), "20261110-1650"))))
    rows.append(("BFCL reminder, miss_func (Module 3)", "8 -> 16 of 50, p = 0.039",
                 compare_arms(load_arm(d(RESEARCH, "20261109-185549")), load_arm(d(RESEARCH, "20261109-205117")),
                              group="miss_func")))
    rows.append(("When2Call probe gate (Ch3 P8)", "75 / 66, p = 0.50",
                 compare_arms(load_arm(d(EXP, "20261115-172227")), load_arm(d(EXP, "20261115-201644")))))
    print("| Result | Published | keel compare | Tier | False success |\n|---|---|---|---|---|")
    for name, pub, c in rows:
        t = c.pass_test
        got = (f"only A {t['only_a']} / only B {t['only_b']}, p = {t['p']:.2g}" if "only_a" in t else
               f"{100 * t['delta']:+.1f} [{100 * t['ci95'][0]:+.1f}, {100 * t['ci95'][1]:+.1f}]")
        fs = f"{100 * c.fs_test['delta']:+.1f}, p = {c.fs_test['p']:.2g}" if c.fs_test else "n/a"
        print(f"| {name} | {pub} | **{c.verdict}**: {got} | {c.tier} | {fs} |")
    return 0


if __name__ == "__main__":
    sys.exit(main())
