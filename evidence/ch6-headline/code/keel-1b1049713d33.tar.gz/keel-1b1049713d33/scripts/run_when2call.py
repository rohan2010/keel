"""Thin wrapper; the code lives in src/keel/commands/run_when2call.py. Same as `keel-core when2call ...`."""

from keel.commands.run_when2call import main

if __name__ == "__main__":
    main()
