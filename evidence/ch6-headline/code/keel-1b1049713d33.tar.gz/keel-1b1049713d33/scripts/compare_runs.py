"""Are two agent runs identical episode by episode? (reproducibility check for per-episode random numbers)

  uv run python scripts/compare_runs.py experiments/<run1> experiments/<run2>
"""

import json
import sys
from pathlib import Path


def load(d):
    return {json.loads(l)["id"]: json.loads(l) for l in open(Path(d) / "outputs.jsonl")}


def main():
    a, b = load(sys.argv[1]), load(sys.argv[2])
    same = diff = 0
    for k in sorted(set(a) & set(b)):
        x, y = a[k], b[k]
        if x["commands"] == y["commands"] and x["answer"] == y["answer"]:
            same += 1
        else:
            diff += 1
            n = next((i for i, (p, q) in enumerate(zip(x["commands"], y["commands"])) if p != q),
                     min(len(x["commands"]), len(y["commands"])))
            print(f"  DIFF {k}: first different step {n}; correct {x['correct']} vs {y['correct']}")
    print(f"identical episodes: {same}/{same + diff}")
    # Ch4 P3: the verdict on the same two runs (keel-core compare; this script stays the episode-by-episode view)
    from keel.evals.compare import compare_arms, load_arm
    c = compare_arms(load_arm(sys.argv[1]), load_arm(sys.argv[2]))
    print(f"keel compare: {c.verdict} ({c.reason})")


if __name__ == "__main__":
    main()
