"""Chapter 4 P0: load every saved run folder with keel.evals.runs and report what loads and what doesn't (and why).
Read-only.

  uv run python scripts/audit_runs.py [--no-fs] [base ...]      (default bases: results/runs experiments)
"""

import argparse
import collections
import sys
import time

from keel.evals.runs import RunUnreadable, find_runs, load_run


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("bases", nargs="*", default=["results/runs", "experiments"])
    ap.add_argument("--no-fs", action="store_true", help="skip BFCL false-success labels (fast)")
    a = ap.parse_args()
    ok = collections.Counter()
    bad: list[tuple[str, str]] = []
    incomplete = []
    t0 = time.time()
    for d in find_runs(*a.bases):
        try:
            h, recs = load_run(d, fs=not a.no_fs)
        except RunUnreadable as err:
            bad.append((str(d), str(err).split(": ", 1)[-1]))
            continue
        ok[h.suite] += 1
        if h.missing:
            incomplete.append((str(d), len(recs), len(h.items)))
    print(f"loaded: {dict(ok)} ({sum(ok.values())} runs, {time.time() - t0:.0f} s)")
    print(f"incomplete (loaded, items missing): {len(incomplete)}")
    for d, n, m in incomplete:
        print(f"  {d}: {n} of {m} items")
    print(f"not loaded: {len(bad)}")
    for d, why in bad:
        print(f"  {d}: {why}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
