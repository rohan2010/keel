"""Re-score a finished agent run with the current scorers (after a scorer fix), from the saved sandbox folders and
transcripts. Keeps the first scoring as outputs_scored_<timestamp>.jsonl and logs which items changed.

  uv run python scripts/rescore_agent.py experiments/<run>
"""

import json
import sys
import time
from collections import defaultdict
from pathlib import Path

from keel.agent import tasks as T


def main():
    d = Path(sys.argv[1])
    rows = [json.loads(l) for l in (d / "outputs.jsonl").open()]
    (d / f"outputs_scored_{time.strftime('%Y%m%d-%H%M%S')}.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    changed = []
    for r in rows:
        item = T.build(r["task"], r["seed"])
        s = T.score(item, d / "sandboxes" / r["id"] / "work", r["answer"], r["commands"], r.get("confirmations", []))
        if bool(s["correct"]) != r["correct"] or abs(s["score"] - r["score"]) > 1e-9:
            changed.append((r["id"], r["correct"], bool(s["correct"]), round(r["score"], 2), round(s["score"], 2)))
        r.update(correct=bool(s["correct"]), score=s["score"], labels=s.get("labels", []),
                 detail={k: v for k, v in s.items() if k not in ("correct", "score", "labels")})
    (d / "outputs.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    # metrics.json must match the rescored outputs (same layout as run_agent.py); the old one is kept alongside
    if (d / "metrics.json").exists():
        (d / f"metrics_scored_{time.strftime('%Y%m%d-%H%M%S')}.json").write_text((d / "metrics.json").read_text())
    by = defaultdict(list)
    for r in rows:
        by[r["task"]].append(r)
    metrics = {t: {"n": len(v), "correct": sum(r["correct"] for r in v), "mean_score": sum(r["score"] for r in v) / len(v),
                   "mean_steps": sum(r["steps"] for r in v) / len(v)} for t, v in sorted(by.items())}
    useful = [r for r in rows if r["kind"] != "safety"]
    metrics["overall_useful"] = {"n": len(useful), "correct": sum(r["correct"] for r in useful)}
    (d / "metrics.json").write_text(json.dumps(metrics, indent=1))
    for c in changed:
        print(f"  {c[0]}: correct {c[1]} -> {c[2]}, score {c[3]} -> {c[4]}")
    print(f"{len(changed)} items changed; {sum(r['correct'] for r in rows if r['kind'] != 'safety')}/"
          f"{sum(r['kind'] != 'safety' for r in rows)} useful items correct")


if __name__ == "__main__":
    main()
