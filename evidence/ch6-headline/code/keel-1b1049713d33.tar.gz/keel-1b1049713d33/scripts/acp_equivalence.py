"""Chapter 2, P8: the interactive path (ACP session) gives the same agent behaviour as the eval path.

    uv run python scripts/acp_equivalence.py <golden_tag>        e.g. c2  (compares with golden_<tag>_agent)

Runs the 13 keel tasks through `keel.acp_server` in-process (Session, streamed updates, the delete-guard question
bridge answered "allow" like the golden run's simulated user) with the golden run's settings (greedy, seed 0,
batch 1, files toolset, loop breaker, trim). Two things differ from `keel run` on purpose and are made equal here:
- sampling: interactive runs use temperature 0.7; here it is greedy, like the eval;
- the sandbox: `keel run` works in place with real file dates; here `Sandbox.for_folder` is patched to return the
  eval's sandbox (a copy of the task template, the logical clock) so file listings match. The server itself has no
  switch for this.
Then every transcript is compared message by message with the golden run's.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import golden_compare as G  # noqa: E402
from acp import schema as s  # noqa: E402

from keel import acp_server as A  # noqa: E402
from keel.agent import tasks as T  # noqa: E402
from keel.agent.loop import prompt_ids  # noqa: E402
from keel.agent.sandbox import Sandbox  # noqa: E402
from keel.backends.mlx import MLXBackend  # noqa: E402
from keel.core.backend import RunLimits  # noqa: E402
from keel.m4 import make_trimmer  # noqa: E402
from keel.model import load_model  # noqa: E402
from keel.specs import QWEN35_4B_8BIT, ModelSpec, SamplingSpec  # noqa: E402


class Conn:
    """Stands in for the client: records updates, allows every delete (the golden run's approve_all)."""

    def __init__(self):
        self.updates, self.asked = [], 0

    async def session_update(self, sid, update, **kw):
        self.updates.append(update)

    async def request_permission(self, sid, tool_call, options, **kw):
        self.asked += 1
        allow = next(o.option_id for o in options if o.kind == "allow_once")
        return s.RequestPermissionResponse(outcome=s.AllowedOutcome(outcome="selected", option_id=allow))


async def main(tag: str) -> int:
    out = ROOT / "experiments" / f"acp_equivalence_{tag}"
    golden = G.load(G.run_dir(tag, "agent"))
    b = QWEN35_4B_8BIT
    spec = ModelSpec(b.name, b.hf_repo, b.revision, b.local_dir, {"enable_thinking": False})
    sampling = SamplingSpec(temperature=0.0, top_p=0.8, top_k=20, presence_penalty=0.0, max_tokens=8192, seed=0)
    model, tok = load_model(spec)
    engine = A.Engine(MLXBackend(model, tok, sampling), lambda e: prompt_ids(tok, spec, e.messages, e.toolset),
                      make_trimmer(tok), RunLimits(batch_size=1, max_context=16000, context_budget=32000,
                                                   progress_every=0, extra={"prefill_batch": 1, "prefill_step": 1024}),
                      "mlx")

    items = {it.id: it for it in (T.build(t, i) for t in T.TASKS for i in range(1))}
    current: dict = {}

    def eval_sandbox(folder, session_id, state_dir=None, **kw):     # the patch: the eval's own sandbox
        it = current["item"]
        tmpl = T.materialize(it, out / "templates" / it.id)
        return Sandbox(out / "sandboxes" / it.id).create(tmpl)
    A.Sandbox.for_folder = staticmethod(eval_sandbox)

    agent = A.KeelAgent(lambda: engine, out / "state")
    conn = Conn()
    agent.on_connect(conn)
    await agent.initialize(protocol_version=1)
    results, same = {}, 0
    for iid in sorted(golden):
        it = items[iid]
        current["item"] = it
        new = await agent.new_session(cwd=str(out))
        sess = agent.sessions[new.session_id]
        sess.ep.item = it                                           # same episode id -> same per-episode stream
        r = await agent.prompt(session_id=new.session_id,
                               prompt=[s.TextContentBlock(type="text", text=it.request)])
        msgs = sess.ep.messages
        g = golden[iid]["messages"]
        norm = lambda ms, root: json.loads(json.dumps(ms).replace(str(root), "<RUN>"))
        a, bb = norm(msgs, sess.sandbox.root.parent.parent), g          # golden: already normalized on load
        d = G.first_diff(bb, a, ".messages")
        confs = [c.__dict__ for c in sess.ep.shell.log]
        sc = T.score(it, sess.sandbox.work, sess.ep.answer, sess.ep.commands, confs)
        results[iid] = {"identical": d is None, "first_diff": d, "correct": bool(sc["correct"]),
                        "golden_correct": bool(golden[iid].get("correct")), "stop": r.stop_reason}
        same += d is None
        print(f"{iid:6s} {'SAME' if d is None else 'DIFF'}  correct {sc['correct']!s:5} (golden "
              f"{golden[iid].get('correct')!s:5})  {'' if d is None else d[:150]}", flush=True)
    (out / "results.json").write_text(json.dumps(results, indent=1))
    print(f"identical {same}/{len(results)}; passed {sum(r['correct'] for r in results.values())} vs golden "
          f"{sum(r['golden_correct'] for r in results.values())}; deletes asked over ACP: {conn.asked}; "
          f"updates sent: {len(conn.updates)}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main(sys.argv[1])))
