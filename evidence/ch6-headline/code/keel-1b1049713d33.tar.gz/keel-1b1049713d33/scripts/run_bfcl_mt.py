"""Thin wrapper kept for the old command lines; the code lives in src/keel/commands/run_bfcl_mt.py.

Same as `keel-core bfcl-mt ...`.
"""

from keel.commands.run_bfcl_mt import main

if __name__ == "__main__":
    main()
