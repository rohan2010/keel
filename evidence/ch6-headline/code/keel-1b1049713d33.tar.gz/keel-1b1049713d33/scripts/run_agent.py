"""Thin wrapper kept for the old command lines; the code lives in src/keel/commands/run_agent.py.

Same as `keel-core run ...`.
"""

from keel.commands.run_agent import main

if __name__ == "__main__":
    main()
