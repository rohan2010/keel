"""False-success table for finished runs (src/keel/false_success.py). Reads outputs only; no model.

  uv run python scripts/false_success.py experiments/<run> [experiments/<run> ...]
  uv run python scripts/false_success.py --sample 20 experiments/<run>   # print episodes to hand-check the labels
"""

import argparse
import json
import random
from pathlib import Path

from keel.false_success import agent_label, bfcl_label, first_failing_turn, summarize

_ENTRIES: dict = {}


def entry_for(rec: dict) -> dict:
    from keel.evals import bfcl_mt as M
    if not _ENTRIES:
        for c in M.CATEGORIES:
            _ENTRIES.update({e["id"]: e for e in M.load(c)})
    return _ENTRIES[rec["id"]]


def load(run: Path) -> list[dict]:
    # outputs.jsonl is the current scoring. outputs_scored_<time>.jsonl are backups of EARLIER scorings
    # (rescore_agent.py writes the old one there, then rewrites outputs.jsonl); reading the latest backup, as this
    # script used to ("latest rescore wins"), gave the scoring before the last rescore (Ch4 P0, 2026-11-16).
    return [json.loads(l) for l in open(run / "outputs.jsonl") if l.strip()]


def label(rec: dict):
    if "valid" not in rec:
        return agent_label(rec)
    if "_fs" not in rec:
        ft = None if rec["valid"] or rec.get("stop") != "done" else first_failing_turn(rec, entry_for(rec))
        rec["_ft"], rec["_fs"] = ft, bfcl_label(rec, ft)
    return rec["_fs"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+")
    ap.add_argument("--sample", type=int, default=0, help="print N random failed items with label and final words")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    print(f"{'run':62s} {'n':>4s} {'pass':>5s} {'false':>6s} {'honest':>7s} {'no ans':>7s} {'FS rate':>8s} {'FS/failed':>9s}")
    for r in a.runs:
        recs = load(Path(r))
        s = summarize([label(x) for x in recs])
        print(f"{Path(r).name[:62]:62s} {s['n']:4d} {s['pass']:5d} {s['false_success']:6d} {s['honest_fail']:7d} "
              f"{s['no_answer']:7d} {100 * s['fs_rate']:7.1f}% {100 * s['fs_of_failed']:8.1f}%")
        if a.sample:
            fails = [x for x in recs if label(x) in ("false_success", "honest_fail")]
            for x in random.Random(a.seed).sample(fails, min(a.sample, len(fails))):
                if "valid" in x:
                    t = x["result"][x["_ft"]] if x.get("_ft") is not None else x["result"][-1]
                    words = f"turn {x.get('_ft')}: " + next((s for s in reversed(t) if isinstance(s, str)), "")[:300]
                else:
                    words = (x.get("answer") or "")[:400]
                print(f"  [{label(x):13s}] {x['id']}: {words!r}")


if __name__ == "__main__":
    main()
